1. Put SmartSteamEmu folder in the game folder
2. In the SmartSteamEmu.ini change InjectDll = 0 to InjectDll = 1
3. Run the game from the SmartSteamLoader.exe or SmartSteamLoader_x64.exe

(Do not use it on already unpacked/patched .exes it most likely slow down your game to 1 FPS)